﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AwsS3.Models
{
    public class Constants
    {
        public static string AccessKey = "AccessKey";
        public static string SecretKey = "SecretKey";
    }
}
