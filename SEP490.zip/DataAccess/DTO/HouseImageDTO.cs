﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DTO
{
    public class HouseImageDTO
    {
        public int HIId { get; set; }
        public string HouseImageCode { get; set; }
        public int HoId { get; set; }
    }
}
