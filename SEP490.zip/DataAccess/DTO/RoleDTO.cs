﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DTO
{
    public class RoleDTO
    {
        public int RId { get; set; }
        public string RoleName { get; set; }
    }
}
