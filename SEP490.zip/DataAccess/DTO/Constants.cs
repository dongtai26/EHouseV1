﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.DTO
{
    public class Constants
    {
        public static string AccesKey = "AccessKey";
        public static string SecretKey = "SecretKey";
    }
}
